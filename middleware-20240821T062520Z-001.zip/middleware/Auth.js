const Auth = async(req, res, next) => {

    const { id } = req.cookies

    if (id) {
        next()
    } else {
        res.redirect("/user/signinForm")
    }

}
const valid = async (req, res, next) => {
    const { username, email, password } = req.body
    if (!username || !email || !password) {
        next();
    }
    else {
        res.redirect("/user/signup")
    }
}


module.exports = {
    Auth,
    valid
}