const mongoose=require("mongoose")

const signInSchema=new mongoose.Schema({
  
    Email:String,
    Password:String,
    ConfirmPassword:String
})

const signInModel=mongoose.model("signin",signInSchema)

module.exports=signInModel