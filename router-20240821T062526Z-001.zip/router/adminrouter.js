const express=require("express")
const routerr=express.Router()
const {signedin,header,admin,signinForm,loginForm,logedin,local,blog,blogdetail,deleteblog} = require("../controller/admincontroller")
const {Auth,valid} = require("../middleware/Auth")
const passport = require("passport")
routerr.get("/",header)
routerr.get("/signinform",signinForm)
routerr.get("/loginform", loginForm)
routerr.post("/signedin",signedin)
routerr.post("/logedin", logedin)
routerr.get("/blog",Auth,blog)
routerr.get("/admin",valid,admin)
routerr.post("/blogdetail",blogdetail)
routerr.delete("/deleteblog",deleteblog)

routerr.post("/local",passport.authenticate("local"),local)

module.exports=routerr